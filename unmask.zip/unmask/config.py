import os

class Config(object):
    SECRET_KEY = "fdsafasd"