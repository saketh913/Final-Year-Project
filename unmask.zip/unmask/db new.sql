/*
SQLyog Community Edition- MySQL GUI v7.15 
MySQL - 5.5.29 : Database - userbehaviour
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`userbehaviour` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `userbehaviour`;

/*Table structure for table `accountdetails` */

DROP TABLE IF EXISTS `accountdetails`;

CREATE TABLE `accountdetails` (
  `username` varchar(50) DEFAULT NULL,
  `branch` varchar(50) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `accountdetails` */

insert  into `accountdetails`(`username`,`branch`,`email`,`address`,`mobile`,`amount`) values ('ramu','ameerpet','ramu@gmail.com','Ameerpet','9052016340',68000),('shiva','ameerpet','shiva@gmail.com','hyd','9875641230',25000),('chinna','sbi','chinna@gmail.com','hyd','8639966858',480000),('chinnu','sbi','chinnu@gmail.com','hyd','8639966858',480000);

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`username`,`password`) values ('admin','admin');

/*Table structure for table `analyst` */

DROP TABLE IF EXISTS `analyst`;

CREATE TABLE `analyst` (
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `analyst` */

insert  into `analyst`(`username`,`password`) values ('analyst','analyst');

/*Table structure for table `books` */

DROP TABLE IF EXISTS `books`;

CREATE TABLE `books` (
  `book_name` varchar(100) DEFAULT NULL,
  `book_desc` varchar(100) DEFAULT NULL,
  `id` int(100) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `books` */

/*Table structure for table `cancelledproducts` */

DROP TABLE IF EXISTS `cancelledproducts`;

CREATE TABLE `cancelledproducts` (
  `username` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `productname` varchar(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cancelledproducts` */

insert  into `cancelledproducts`(`username`,`category`,`productname`,`price`,`image`) values ('ramu','Laptops','dell laptop',25000,'dell.jpeg'),('chinnu','dell','dell new',10000,'dell.jpeg');

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `username` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `productname` varchar(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `cart` */

insert  into `cart`(`username`,`category`,`productname`,`price`,`image`) values ('ramu','Mobiles','samsung',10000,'samsung1.jpg');

/*Table structure for table `category` */

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `category` */

insert  into `category`(`id`,`category`) values (1,'Sports'),(2,'Mobiles'),(3,'Laptops'),(4,'Benz'),(5,'Honda'),(6,'dell'),(7,'electronics');

/*Table structure for table `filters` */

DROP TABLE IF EXISTS `filters`;

CREATE TABLE `filters` (
  `words` varchar(100) DEFAULT NULL,
  `Value` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `filters` */

insert  into `filters`(`words`,`Value`) values ('wonderful',1),('good',1),('supportive',1),('inspiring',1),('amazing',1),('motivative',1),('helpful',1),('beautiful',1),('friendly',1),('excellent',1),('awesome',1),('unbelieviable',1),('super',1),('tarrific',1),('well done',1),('delightful',1),('super',1),('fantastic',1),('brilliant',1),('beautiful',1),('nice',1),('verynice',1),('verygood',1),('bad',3),('verybad',3),('worst',3),('disappointing',3),('irritating',3),('ugly',3),('useless',3),('weak',3),('unwilling',3),('unintersted',3),('refusing',3),('sad',3),('awful',3),('poor',3),('cool',1),('kill you',2),('fool',2),('stupid',2),('idot',2),('bleady',2);

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(40) DEFAULT NULL,
  `productname` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `products` */

insert  into `products`(`id`,`category`,`productname`,`description`,`price`,`brand`,`image`) values (4,'Honda','maruthi 500','good car in speed',20000,'honda','dell.jpeg'),(5,'dell','dell new','good',10000,'dell','dell.jpeg'),(6,'Mobiles','samsung','samsung',10000,'samsung','samsung1.jpg');

/*Table structure for table `purchasedproducts` */

DROP TABLE IF EXISTS `purchasedproducts`;

CREATE TABLE `purchasedproducts` (
  `username` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `productname` varchar(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `dt` text,
  `image` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `purchasedproducts` */

insert  into `purchasedproducts`(`username`,`category`,`productname`,`price`,`dt`,`image`,`status`) values ('shiva','dell','dell new',10000,'28/03/2024 20:54:50','dell.jpeg','normal');

/*Table structure for table `purchasestatus` */

DROP TABLE IF EXISTS `purchasestatus`;

CREATE TABLE `purchasestatus` (
  `username` varchar(50) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `productname` varchar(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `dt` text,
  `image` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `purchasestatus` */

insert  into `purchasestatus`(`username`,`category`,`productname`,`price`,`dt`,`image`,`status`) values ('shiva','dell','dell new',10000,'28/03/2024 20:54:50','dell.jpeg','normal'),('ramu','Mobiles','samsung',10000,'04/04/2024 09:10:46','samsung1.jpg','Fraud Activity Predicted in Online Shopping');

/*Table structure for table `recomend` */

DROP TABLE IF EXISTS `recomend`;

CREATE TABLE `recomend` (
  `author` varchar(100) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `Image` varchar(200) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `recomend` */

/*Table structure for table `recommends` */

DROP TABLE IF EXISTS `recommends`;

CREATE TABLE `recommends` (
  `username` varchar(40) DEFAULT NULL,
  `productname` varchar(40) DEFAULT NULL,
  `recommendto` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `recommends` */

insert  into `recommends`(`username`,`productname`,`recommendto`) values ('ramu','Samsung J7','shiva'),('chinnu','dell new','chintu');

/*Table structure for table `reviews` */

DROP TABLE IF EXISTS `reviews`;

CREATE TABLE `reviews` (
  `username` varchar(100) DEFAULT NULL,
  `productname` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `review` varchar(100) DEFAULT NULL,
  `rating` varchar(100) DEFAULT NULL,
  `sentiment` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `reviews` */

insert  into `reviews`(`username`,`productname`,`category`,`review`,`rating`,`sentiment`) values ('chinna','maruthi 500','Honda','good','5','positive'),('munna','maruthi 500','Honda','good','5','positive'),('chinnu','dell new','dell','good','5',NULL);

/*Table structure for table `upload` */

DROP TABLE IF EXISTS `upload`;

CREATE TABLE `upload` (
  `bookid` varchar(100) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `book_desc` varchar(10000) DEFAULT NULL,
  `book_from` varchar(100) DEFAULT NULL,
  `book_title` varchar(100) DEFAULT NULL,
  `image` varchar(10000) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `upload` */

insert  into `upload`(`bookid`,`author`,`book_desc`,`book_from`,`book_title`,`image`,`price`) values ('2','J.K. Rowling|Mary','There is a door at the end of a silent corridor. And itâ€™s haunting Harry Pottterâ€™s dreams. Why else would he be waking in the middle of the night, screaming in terror?Harry has a lot on his mind for this, his fifth year at Hogwarts: a Defense Against the Dark Arts teacher with a personality like poisoned honey; a big surprise on the Gryffindor Quidditch team; and the looming terror of the Ordinary Wizarding Level exams. But all these things pale next to the growing threat of He-Who-Must-Not-Be-Named---a threat that neither the magical government nor the authorities at Hogwarts can stop.As the grasp of darkness tightens, Harry must discover the true depth and strength of his friends, the importance of boundless loyalty, and the shocking price of unbearable sacrifice.His fate depends on them alll.(back cover)','Paperback','Harry Potter and the Order of the Phoenix','https://images.gr-assets.com/books/1255614970l/2.jpg','870'),('3','Harper Lee','The unforgettable novel of a childhood in a sleepy Southern town and the crisis of conscience that rocked it, To Kill A Mockingbird became both an instant bestseller and a critical success when it was first published in 1960. It went on to win the Pulitzer Prize in 1961 and was later made into an Academy Award-winning film, also a classic.Compassionate, dramatic, and deeply moving, To Kill A Mockingbird takes readers to the roots of human behavior - to innocence and experience, kindness and cruelty, love and hatred, humor and pathos. Now with over 18 million copies in print and translated into forty languages, this regional story by a young Alabama woman claims universal appeal. Harper Lee always considered her book to be a simple love story. Today it is regarded as a masterpiece of American literature.','Paperback','To Kill a Mockingbird','https://images.gr-assets.com/books/1361975680l/2657.jpg','324'),('5','Markus Zusak','Trying to make sense of the horrors of World War II, Death relates the story of Liesel--a young German girl whose book-stealing and story-telling talents help sustain her family and the Jewish man they are hiding, as well as their neighbors.','Hardcover','The Book Thief','https://images.gr-assets.com/books/1522157426l/19063.jpg','552'),('6','C.S. Lewis|Pauline Baynes','Journeys to the end of the world, fantastic creatures, and epic battles between good and evilâ€”what more could any reader ask for in one book? The book that has it all is The Lion, the Witch and the Wardrobe, written in 1949 by Clive Staples Lewis. But Lewis did not stop there. Six more books followed, and together they became known as The Chronicles of Narnia.For the past fifty years, The Chronicles of Narnia have transcended the fantasy genre to become part of the canon of classic literature. Each of the seven books is a masterpiece, drawing the reader into a land where magic meets reality, and the result is a fictional world whose scope has fascinated generations.This edition presents all seven booksâ€”unabridgedâ€”in one impressive volume. The books are presented here in chronlogical order, each chapter graced with an illustration by the original artist, Pauline Baynes. Deceptively simple and direct, The Chronicles of Narnia continue to captivate fans with adventures, characters, and truths that speak to readers of all ages, even fifty years after they were first published.','Paperback','The Chronicles of Narnia','https://images.gr-assets.com/books/1449868701l/11127.jpg','767'),('12','Dan Brown','An ingenious code hidden in the works of Leonardo da Vinci.A desperate race through the cathedrals and castles of Europe.An astonishing truth concealed for centuries . . . unveiled at last.While in Paris, Harvard symbologist Robert Langdon is awakened by a phone call in the dead of the night. The elderly curator of the Louvre has been murdered inside the museum, his body covered in baffling symbols. As Langdon and gifted French cryptologist Sophie Neveu sort through the bizarre riddles, they are stunned to discover a trail of clues hidden in the works of Leonardo da Vinciâ€”clues visible for all to see and yet ingeniously disguised by the painter.Even more startling, the late curator was involved in the Priory of Sionâ€”a secret society whose members included Sir Isaac Newton, Victor Hugo, and Da Vinciâ€”and he guarded a breathtaking historical secret. Unless Langdon and Neveu can decipher the labyrinthine puzzleâ€”while avoiding the faceless adversary who shadows their every moveâ€”the explosive, ancient truth will be lost forever.','Paperback','The Da Vinci Code','https://images.gr-assets.com/books/1303252999l/968.jpg','481'),('16','Victor Hugo|Lee Fahnestock|Norman MacAfee','Introducing one of the most famous characters in literature, Jean Valjeanâ€”the noble peasant imprisoned for stealing a loaf of breadâ€”Les MisÃ©rables ranks among the greatest novels of all time. In it, Victor Hugo takes readers deep into the Parisian underworld, immerses them in a battle between good and evil, and carries them to the barricades during the uprising of 1832 with a breathtaking realism that is unsurpassed in modern prose. Within his dramatic story are themes that capture the intellect and the emotions: crime and punishment, the relentless persecution of Valjean by Inspector Javert, the desperation of the prostitute Fantine, the amorality of the rogue ThÃ©nardier, and the universal desire to escape the prisons of our own minds. Les MisÃ©rables gave Victor Hugo a canvas upon which he portrayed his criticism of the French political and judicial systems, but the portrait that resulted is larger than life, epic in scopeâ€”an extravagant spectacle that dazzles the senses even as it touches the heart.','Mass Market Paperback','Les MisÃ©rables','https://images.gr-assets.com/books/1525303092l/24280.jpg','1463'),('2440','Eliezer Yudkowsky','Harry Potter and the Methods of Rationality is a work of alternate-universe Harry Potter fan-fiction wherein Petunia Evans has married an Oxford biochemistry professor and young genius Harry grows up fascinated by science and science fiction. When he finds out that he is a wizard, he tries to apply scientific principles to his study of magic, with sometimes surprising results.','ebook','Harry Potter and the Methods of Rationality','https://images.gr-assets.com/books/1293582551l/10016013.jpg','1000'),('48','J.K. Rowling|Mary','Harry Potter\'s life is miserable. His parents are dead and he\'s stuck with his heartless relatives, who force him to live in a tiny closet under the stairs. But his fortune changes when he receives a letter that tells him the truth about himself: he\'s a wizard. A mysterious visitor rescues him from his relatives and takes him to his new home, Hogwarts School of Witchcraft and Wizardry.After a lifetime of bottling up his magical powers, Harry finally feels like a normal kid. But even within the Wizarding community, he is special. He is the boy who lived: the only person to have ever survived a killing curse inflicted by the evil Lord Voldemort, who launched a brutal takeover of the Wizarding world, only to vanish after failing to kill Harry.Though Harry\'s first year at Hogwarts is the best of his life, not everything is perfect. There is a dangerous secret object hidden within the castle walls, and Harry believes it\'s his responsibility to prevent it from falling into evil hands. But doing so will bring him into contact with forces more terrifying than he ever could have imagined.Full of sympathetic characters, wildly imaginative situations, and countless exciting details, the first installment in the series assembles an unforgettable magical world and sets the stage for many high-stakes adventures to come.','Hardcover','Harry Potter and the Sorcerer\'s Stone','https://images.gr-assets.com/books/1474154022l/3.jpg','320'),('85','J.K. Rowling|Mary','Harry Potter is leaving Privet Drive for the last time. But as he climbs into the sidecar of Hagridâ€™s motorbike and they take to the skies, he knows Lord Voldemort and the Death Eaters will not be far behind.The protective charm that has kept him safe until now is broken. But the Dark Lord is breathing fear into everything he loves. And he knows he canâ€™t keep hiding.To stop Voldemort, Harry knows he must find the remaining Horcruxes and destroy them.He will have to face his enemy in one final battle.--jkrowling.com','Hardcover','Harry Potter and the Deathly Hallows','https://images.gr-assets.com/books/1474171184l/136251.jpg','759'),('2','J.K. Rowling|Mary GrandPré','There is a door at the end of a silent corridor. And it’s haunting Harry Pottter’s dreams. Why else would he be waking in the middle of the night, screaming in terror?Harry has a lot on his mind for this, his fifth year at Hogwarts: a Defense Against the Dark Arts teacher with a personality like poisoned honey; a big surprise on the Gryffindor Quidditch team; and the looming terror of the Ordinary Wizarding Level exams. But all these things pale next to the growing threat of He-Who-Must-Not-Be-Named---a threat that neither the magical government nor the authorities at Hogwarts can stop.As the grasp of darkness tightens, Harry must discover the true depth and strength of his friends, the importance of boundless loyalty, and the shocking price of unbearable sacrifice.His fate depends on them alll.(back cover)','Paperback','Harry Potter and the Order of the Phoenix','https://images.gr-assets.com/books/1255614970l/2.jpg','870'),('3','Harper Lee','The unforgettable novel of a childhood in a sleepy Southern town and the crisis of conscience that rocked it, To Kill A Mockingbird became both an instant bestseller and a critical success when it was first published in 1960. It went on to win the Pulitzer Prize in 1961 and was later made into an Academy Award-winning film, also a classic.Compassionate, dramatic, and deeply moving, To Kill A Mockingbird takes readers to the roots of human behavior - to innocence and experience, kindness and cruelty, love and hatred, humor and pathos. Now with over 18 million copies in print and translated into forty languages, this regional story by a young Alabama woman claims universal appeal. Harper Lee always considered her book to be a simple love story. Today it is regarded as a masterpiece of American literature.','Paperback','To Kill a Mockingbird','https://images.gr-assets.com/books/1361975680l/2657.jpg','324'),('5','Markus Zusak','Trying to make sense of the horrors of World War II, Death relates the story of Liesel--a young German girl whose book-stealing and story-telling talents help sustain her family and the Jewish man they are hiding, as well as their neighbors.','Hardcover','The Book Thief','https://images.gr-assets.com/books/1522157426l/19063.jpg','552'),('6','C.S. Lewis|Pauline Baynes','Journeys to the end of the world, fantastic creatures, and epic battles between good and evil—what more could any reader ask for in one book? The book that has it all is The Lion, the Witch and the Wardrobe, written in 1949 by Clive Staples Lewis. But Lewis did not stop there. Six more books followed, and together they became known as The Chronicles of Narnia.For the past fifty years, The Chronicles of Narnia have transcended the fantasy genre to become part of the canon of classic literature. Each of the seven books is a masterpiece, drawing the reader into a land where magic meets reality, and the result is a fictional world whose scope has fascinated generations.This edition presents all seven books—unabridged—in one impressive volume. The books are presented here in chronlogical order, each chapter graced with an illustration by the original artist, Pauline Baynes. Deceptively simple and direct, The Chronicles of Narnia continue to captivate fans with adventures, characters, and truths that speak to readers of all ages, even fifty years after they were first published.','Paperback','The Chronicles of Narnia','https://images.gr-assets.com/books/1449868701l/11127.jpg','767'),('12','Dan Brown','An ingenious code hidden in the works of Leonardo da Vinci.A desperate race through the cathedrals and castles of Europe.An astonishing truth concealed for centuries . . . unveiled at last.While in Paris, Harvard symbologist Robert Langdon is awakened by a phone call in the dead of the night. The elderly curator of the Louvre has been murdered inside the museum, his body covered in baffling symbols. As Langdon and gifted French cryptologist Sophie Neveu sort through the bizarre riddles, they are stunned to discover a trail of clues hidden in the works of Leonardo da Vinci—clues visible for all to see and yet ingeniously disguised by the painter.Even more startling, the late curator was involved in the Priory of Sion—a secret society whose members included Sir Isaac Newton, Victor Hugo, and Da Vinci—and he guarded a breathtaking historical secret. Unless Langdon and Neveu can decipher the labyrinthine puzzle—while avoiding the faceless adversary who shadows their every move—the explosive, ancient truth will be lost forever.','Paperback','The Da Vinci Code','https://images.gr-assets.com/books/1303252999l/968.jpg','481'),('16','Victor Hugo|Lee Fahnestock|Norman MacAfee','Introducing one of the most famous characters in literature, Jean Valjean—the noble peasant imprisoned for stealing a loaf of bread—Les Misérables ranks among the greatest novels of all time. In it, Victor Hugo takes readers deep into the Parisian underworld, immerses them in a battle between good and evil, and carries them to the barricades during the uprising of 1832 with a breathtaking realism that is unsurpassed in modern prose. Within his dramatic story are themes that capture the intellect and the emotions: crime and punishment, the relentless persecution of Valjean by Inspector Javert, the desperation of the prostitute Fantine, the amorality of the rogue Thénardier, and the universal desire to escape the prisons of our own minds. Les Misérables gave Victor Hugo a canvas upon which he portrayed his criticism of the French political and judicial systems, but the portrait that resulted is larger than life, epic in scope—an extravagant spectacle that dazzles the senses even as it touches the heart.','Mass Market Paperback','Les Misérables','https://images.gr-assets.com/books/1525303092l/24280.jpg','1463'),('18','Charlotte Brontë|Michael Mason','Fiery love, shocking twists of fate, and tragic mysteries put a lonely governess in jeopardy in JANE EYRE Orphaned as a child, Jane has felt an outcast her whole young life. Her courage is tested once again when she arrives at Thornfield Hall, where she has been hired by the brooding, proud Edward Rochester to care for his ward Adèle. Jane finds herself drawn to his troubled yet kind spirit. She falls in love. Hard. But there is a terrifying secret inside the gloomy, forbidding Thornfield Hall. Is Rochester hiding from Jane? Will Jane be left heartbroken and exiled once again?','Paperback','Jane Eyre','https://images.gr-assets.com/books/1327867269l/10210.jpg','507'),('20','William Golding','At the dawn of the next world war, a plane crashes on an uncharted island, stranding a group of schoolboys. At first, with no adult supervision, their freedom is something to celebrate; this far from civilization the boys can do anything they want. Anything. They attempt to forge their own society, failing, however, in the face of terror, sin and evil. And as order collapses, as strange howls echo in the night, as terror begins its reign, the hope of adventure seems as far from reality as the hope of being rescued. Labeled a parable, an allegory, a myth, a morality tale, a parody, a political treatise, even a vision of the apocalypse, Lord of the Flies is perhaps our most memorable tale about “the end of innocence, the darkness of man’s heart.”','Paperback','Lord of the Flies','https://images.gr-assets.com/books/1327869409l/7624.jpg','182'),('22','Fyodor Dostoyevsky|David McDuff','Raskolnikov, an impoverished student living in the St. Petersburg of the tsars, is determined to overreach his humanity and assert his untrammeled individual will. When he commits an act of murder and theft, he sets into motion a story that, for its excruciating suspense, its atmospheric vividness, and its depth of characterization and vision is almost unequaled in the literatures of the world. The best known of Dostoevsky’s masterpieces, Crime and Punishment can bear any amount of rereading without losing a drop of its power over our imaginations.Dostoevsky’s drama of sin, guilt, and redemption transforms the sordid story of an old woman’s murder into the nineteenth century’s profoundest and most compelling philosophical novel.Award-winning translators Richard Pevear and Larissa Volokhonsky render this elusive and wildly innovative novel with an energy, suppleness, and range of voice that do full justice to the genius of its creator.','Paperback','Crime and Punishment','https://images.gr-assets.com/books/1382846449l/7144.jpg','671'),('24','Stephen Chbosky','The critically acclaimed debut novel from Stephen Chbosky, Perks follows observant “wallflower” Charlie as he charts a course through the strange world between adolescence and adulthood. First dates, family drama, and new friends. Sex, drugs, and The Rocky Horror Picture Show. Devastating loss, young love, and life on the fringes. Caught between trying to live his life and trying to run from it, Charlie must learn to navigate those wild and poignant roller-coaster days known as growing up.Listening Length: 6 hours and 18 minutes','Paperback','The Perks of Being a Wallflower','https://images.gr-assets.com/books/1520093244l/22628.jpg','213'),('27','F. Scott Fitzgerald','Alternate Cover Edition ISBN: 0743273567 (ISBN13: 9780743273565)A true classic of twentieth-century literature, this edition has been updated by Fitzgerald scholar James L.W. West III to include the author’s final revisions and features a note on the composition and text, a personal foreword by Fitzgerald’s granddaughter, Eleanor Lanahan—and a new introduction by two-time National Book Award winner Jesmyn Ward.The Great Gatsby, F. Scott Fitzgerald’s third book, stands as the supreme achievement of his career. First published in 1925, this quintessential novel of the Jazz Age has been acclaimed by generations of readers. The story of the mysteriously wealthy Jay Gatsby and his love for the beautiful Daisy Buchanan, of lavish parties on Long Island at a time when The New York Times noted “gin was the national drink and sex the national obsession,” it is an exquisitely crafted tale of America in the 1920s.','Paperback','The Great Gatsby','https://images.gr-assets.com/books/1490528560l/4671.jpg','180'),('31','John Steinbeck','The compelling story of two outsiders striving to find their place in an unforgiving world. Drifters in search of work, George and his simple-minded friend Lennie have nothing in the world except each other and a dream--a dream that one day they will have some land of their own. Eventually they find work on a ranch in California’s Salinas Valley, but their hopes are doomed as Lennie, struggling against extreme cruelty, misunderstanding and feelings of jealousy, becomes a victim of his own strength. Tackling universal themes such as the friendship of a shared vision, and giving voice to America’s lonely and dispossessed, Of Mice and Men has proved one of Steinbeck’s most popular works, achieving success as a novel, a Broadway play and three acclaimed films.','Paperback','Of Mice and Men','https://images.gr-assets.com/books/1511302904l/890.jpg','112'),('33','Aldous Huxley','Brave New World is a dystopian novel written in 1931 by English author Aldous Huxley, and published in 1932. Largely set in a futuristic World State of genetically modified citizens and an intelligence-based social hierarchy, the novel anticipates huge scientific developments in reproductive technology, sleep-learning, psychological manipulation, and classical conditioning that are combined to make a utopian society that goes challenged only by a single outsider.','Paperback','Brave New World','https://images.gr-assets.com/books/1523061131l/5129.jpg','288'),('34','Gabriel García Márquez|Gregory Rabassa','The brilliant, bestselling, landmark novel that tells the story of the Buendia family, and chronicles the irreconcilable conflict between the desire for solitude and the need for love—in rich, imaginative prose that has come to define an entire genre known as \"magical realism.\"','Hardcover','One Hundred Years of Solitude','https://images.gr-assets.com/books/1327881361l/320.jpg','417'),('35','Antoine de Saint-Exupéry|Richard Howard|Dom Marcos Barbosa|Melina Karakosta','Moral allegory and spiritual autobiography, The Little Prince is the most translated book in the French language. With a timeless charm it tells the story of a little boy who leaves the safety of his own tiny planet to travel the universe, learning the vagaries of adult behaviour through a series of extraordinary encounters. His personal odyssey culminates in a voyage to Earth and further adventures.','Paperback','The Little Prince','https://images.gr-assets.com/books/1367545443l/157993.jpg','93'),('41','Ray Bradbury|Alfredo Crespo','Fahrenheit 451 ofrece la historia de un sombrío y horroroso futuro. Montag, el protagonista, pertenece a una extraña brigada de bomberos cuya misión, paradójicamente, no es la de sofocar incendios sino la de provocarlos, para quemar libros. Porque en el país de Montag está terminantemente prohibido leer. Porque leer obliga a pensar, y en el país de Montag esta prohibido pensar. Porque leer impide ser ingenuamente feliz, y en el país de Montag hay que ser feliz a la fuerza...','Mass Market Paperback','Fahrenheit 451','https://images.gr-assets.com/books/1351643740l/4381.jpg','175'),('42','George R.R. Martin','Here is the first volume in George R. R. Martin’s magnificent cycle of novels that includes A Clash of Kings and A Storm of Swords. As a whole, this series comprises a genuine masterpiece of modern fantasy, bringing together the best the genre has to offer. Magic, mystery, intrigue, romance, and adventure fill these   and transport us to a world unlike any we have ever experienced. Already hailed as a classic, George R. R. Martin’s stunning series is destined to stand as one of the great achievements of imaginative fiction.A GAME OF THRONESLong ago, in a time forgotten, a preternatural event threw the seasons out of balance. In a land where summers can last decades and winters a lifetime, trouble is brewing. The cold is returning, and in the frozen wastes to the north of Winterfell, sinister and supernatural forces are massing beyond the kingdom’s protective Wall. At the center of the conflict lie the Starks of Winterfell, a family as harsh and unyielding as the land they were born to. Sweeping from a land of brutal cold to a distant summertime kingdom of epicurean plenty, here is a tale of lords and ladies, soldiers and sorcerers, assassins and bastards, who come together in a time of grim omens.Here an enigmatic band of warriors bear swords of no human metal; a tribe of fierce wildlings carry men off into madness; a cruel young dragon prince barters his sister to win back his throne; and a determined woman undertakes the most treacherous of journeys. Amid plots and counterplots, tragedy and betrayal, victory and terror, the fate of the Starks, their allies, and their enemies hangs perilously in the balance, as each endeavors to win that deadliest of conflicts: the game of thrones.source: georgerrmartin.com','Mass Market Paperback','A Game of Thrones','https://images.gr-assets.com/books/1436732693l/13496.jpg','848'),('47','Dr. Seuss','“Do you like green eggs and ham?” asks Sam-I-am in this Beginner Book by Dr. Seuss. In a house or with a mouse? In a boat or with a goat? On a train or in a tree? Sam keeps asking persistently. With unmistakable characters and signature rhymes, Dr. Seuss’s beloved favorite has cemented its place as a children’s classic. In this most famous of cumulative tales, the list of places to enjoy green eggs and ham, and friends to enjoy them with, gets longer and longer. Follow Sam-I-am as he insists that this unusual treat is indeed a delectable snack to be savored everywhere and in every way. Originally created by Dr. Seuss, Beginner Books encourage children to read all by themselves, with simple words and illustrations that give clues to their meaning.','Hardcover','Green Eggs and Ham','https://images.gr-assets.com/books/1468680100l/23772.jpg','62'),('49','Yann Martel','Life of Pi is a fantasy adventure novel by Yann Martel published in 2001. The protagonist, Piscine Molitor \"Pi\" Patel, a Tamil boy from Pondicherry, explores issues of spirituality and practicality from an early age. He survives 227 days after a shipwreck while stranded on a boat in the Pacific Ocean with a Bengal tiger named Richard Parker.','Paperback','Life of Pi','https://images.gr-assets.com/books/1320562005l/4214.jpg','460'),('52','Sara Gruen','Winner of the 2007 BookBrowse Award for Most Popular Book.An atmospheric, gritty, and compelling novel of star-crossed lovers, set in the circus world circa 1932, by the bestselling author of Riding Lessons. When Jacob Jankowski, recently orphaned and suddenly adrift, jumps onto a passing train, he enters a world of freaks, drifters, and misfits, a second-rate circus struggling to survive during the Great Depression, making one-night stands in town after endless town. A veterinary student who almost earned his degree, Jacob is put in charge of caring for the circus menagerie. It is there that he meets Marlena, the beautiful young star of the equestrian act, who is married to August, the charismatic but twisted animal trainer. He also meets Rosie, an elephant who seems untrainable until he discovers a way to reach her. Beautifully written, Water for Elephants is illuminated by a wonderful sense of time and place. It tells a story of a love between two people that overcomes incredible odds in a world in which even love is a luxury that few can afford.','Paperback','Water for Elephants','https://images.gr-assets.com/books/1494428973l/43641.jpg','335'),('56','Joseph Heller','The novel is set during World War II, from 1942 to 1944. It mainly follows the life of Captain John Yossarian, a U.S. Army Air Forces B-25 bombardier. Most of the events in the book occur while the fictional 256th Squadron is based on the island of Pianosa, in the Mediterranean Sea, west of Italy. The novel looks into the experiences of Yossarian and the other airmen in the camp, who attempt to maintain their sanity while fulfilling their service requirements so that they may return home.','Paperback','Catch-22','https://images.gr-assets.com/books/1463157317l/168668.jpg','453'),('59','Ken Follett','Ken Follett is known worldwide as the master of split-second suspense, but his most beloved and bestselling book tells the magnificent tale of a twelfth-century monk driven to do the seemingly impossible: build the greatest Gothic cathedral the world has ever known.Everything readers expect from Follett is here: intrigue, fast-paced action, and passionate romance. But what makes The Pillars of the Earth extraordinary is the time the twelfth century; the place feudal England; and the subject the building of a glorious cathedral. Follett has re-created the crude, flamboyant England of the Middle Ages in every detail. The vast forests, the walled towns, the castles, and the monasteries become a familiar landscape. Against this richly imagined and intricately interwoven backdrop, filled with the ravages of war and the rhythms of daily life, the master storyteller draws the reader irresistibly into the intertwined lives of his characters into their dreams, their labors, and their loves: Tom, the master builder; Aliena, the ravishingly beautiful noblewoman; Philip, the prior of Kingsbridge; Jack, the artist in stone; and Ellen, the woman of the forest who casts a terrifying curse. From humble stonemason to imperious monarch, each character is brought vividly to life.The building of the cathedral, with the almost eerie artistry of the unschooled stonemasons, is the center of the drama. Around the site of the construction, Follett weaves a story of betrayal, revenge, and love, which begins with the public hanging of an innocent man and ends with the humiliation of a king.For the Movie tie-in edition with the same ISBN go to this Alternate Cover Edition','Paperback','The Pillars of the Earth','https://images.gr-assets.com/books/1388193707l/5043.jpg','973'),('60','Stephen King|Bernie Wrightson','This is the way the world ends: with a nanosecond of computer error in a Defense Department laboratory and a million casual contacts that form the links in a chain letter of death. And here is the bleak new world of the day after: a world stripped of its institutions and emptied of 99 percent of its people. A world in which a handful of panicky survivors choose sides -- or are chosen.','Hardcover','The Stand','https://images.gr-assets.com/books/1213131305l/149267.jpg','1153'),('61','Lois Lowry','Twelve-year-old Jonas lives in a seemingly ideal world. Not until he is given his life assignment as the Receiver does he begin to understand the dark secrets behind this fragile community.','Paperback','The Giver','https://images.gr-assets.com/books/1342493368l/3636.jpg','208'),('68','Diana Gabaldon','The year is 1945. Claire Randall, a former combat nurse, is just back from the war and reunited with her husband on a second honeymoon when she walks through a standing stone in one of the ancient circles that dot the British Isles. Suddenly she is a Sassenach—an “outlander”—in a Scotland torn by war and raiding border clans in the year of Our Lord...1743.Hurled back in time by forces she cannot understand, Claire is catapulted into the intrigues of lairds and spies that may threaten her life, and shatter her heart. For here James Fraser, a gallant young Scots warrior, shows her a love so absolute that Claire becomes a woman torn between fidelity and desire—and between two vastly different men in two irreconcilable lives.','Mass Market Paperback','Outlander','https://images.gr-assets.com/books/1529065012l/10964.jpg','850'),('69','Stieg Larsson|Reg Keeland','A spellbinding amalgam of murder mystery, family saga, love story and financial intrigue.A Sensational #1 Bestseller – Now a Major Motion Picture In Theaters March 2010.It’s about the disappearance forty years ago of Harriet Vanger, a young scion of one of the wealthiest families in Sweden . . . and about her octogenarian uncle, determined to know the truth about what he believes was her murder.It’s about Mikael Blomkvist, a crusading journalist recently at the wrong end of a libel case, hired to get to the bottom of Harriet’s disappearance . . . and about Lisbeth Salander, a twenty-four-year-old pierced and tattooed genius hacker possessed of the hard-earned wisdom of someone twice her age—and a terrifying capacity for ruthlessness to go with it—who assists Blomkvist with the investigation. This unlikely team discovers a vein of nearly unfathomable iniquity running through the Vanger family, astonishing corruption in the highest echelons of Swedish industrialism—and an unexpected connection between themselves.It’s a contagiously exciting, stunningly intelligent novel about society at its most hidden, and about the intimate lives of a brilliantly realized cast of characters, all of them forced to face the darker aspects of their world and of their own lives.','Hardcover','The Girl with the Dragon Tattoo','https://images.gr-assets.com/books/1327868566l/2429135.jpg','465'),('74','J.R.R. Tolkien','Alternate Cover Edition ISBN 0618260269 (copyright page ISBN is 0618346252 - different from back cover)One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkeness bind themIn ancient times the Rings of Power were crafted by the Elven-smiths, and Sauron, The Dark Lord, forged the One Ring, filling it with his own power so that he could rule all others. But the One Ring was taken from him, and though he sought it throughout Middle-earth, it remained lost to him. After many ages it fell into the hands of Bilbo Baggins, as told in The Hobbit.In a sleepy village in the Shire, young Frodo Baggins finds himself faced with an immense task, as his elderly cousin Bilbo entrusts the Ring to his care. Frodo must leave his home and make a perilous journey across Middle-earth to the Cracks of Doom, there to destroy the Ring and foil the Dark Lord in his evil purpose.--back cover','Paperback','The Fellowship of the Ring','https://images.gr-assets.com/books/1298411339l/34.jpg','398'),('76','Cormac McCarthy','A searing, post apocalyptic novel destined to become Cormac McCarthy’s masterpiece.A father and his son walk alone through burned America. Nothing moves in the ravaged landscape save the ash on the wind. It is cold enough to crack stones, and when the snow falls it is gray. The sky is dark. Their destination is the coast, although they don’t know what, if anything, awaits them there. They have nothing; just a pistol to defend themselves against the lawless bands that stalk the road, the clothes they are wearing, a cart of scavenged food—and each other.','Hardcover','The Road','https://images.gr-assets.com/books/1439197219l/6288.jpg','241'),('84','Ayn Rand|Leonard Peikoff','This is the story of a man who said that he would stop the motor of the world and did. Was he a destroyer or the greatest of liberators?Why did he have to fight his battle, not against his enemies, but against those who needed him most, and his hardest battle against the woman he loved? What is the world’s motor — and the motive power of every man? You will know the answer to these questions when you discover the reason behind the baffling events that play havoc with the lives of the characters in this story. Tremendous in its scope, this novel presents an astounding panorama of human life — from the productive genius who becomes a worthless playboy — to the great steel industrialist who does not know that he is working for his own destruction — to the philosopher who becomes a pirate — to the composer who gives up his career on the night of his triumph — to the woman who runs a transcontinental railroad — to the lowest track worker in her Terminal tunnels. You must be prepared, when you read this novel, to check every premise at the root of your convictions.This is a mystery story, not about the murder — and rebirth — of man’s spirit. It is a philosophical revolution, told in the form of an action thriller of violent events, a ruthlessly brilliant plot structure and an irresistible suspense. Do you say this is impossible? Well, that is the first of your premises to check.','Paperback','Atlas Shrugged','https://images.gr-assets.com/books/1405868167l/662.jpg','1168'),('85','J.K. Rowling|Mary GrandPré','Harry Potter is leaving Privet Drive for the last time. But as he climbs into the sidecar of Hagrid’s motorbike and they take to the skies, he knows Lord Voldemort and the Death Eaters will not be far behind.The protective charm that has kept him safe until now is broken. But the Dark Lord is breathing fear into everything he loves. And he knows he can’t keep hiding.To stop Voldemort, Harry knows he must find the remaining Horcruxes and destroy them.He will have to face his enemy in one final battle.--jkrowling.com','Hardcover','Harry Potter and the Deathly Hallows','https://images.gr-assets.com/books/1474171184l/136251.jpg','759'),('88','Ray Bradbury','The terrifyingly prophetic novel of a post-literate future.Guy Montag is a fireman. His job is to burn books, which are forbidden, being the source of all discord and unhappiness. Even so, Montag is unhappy; there is discord in his marriage. Are books hidden in his house? The Mechanical Hound of the Fire Department, armed with a lethal hypodermic, escorted by helicopters, is ready to track down those dissidents who defy society to preserve and read books.The classic dystopian novel of a post-literate future, Fahrenheit 451 stands alongside Orwell’s 1984 and Huxley’s Brave New World as a prophetic account of Western civilization’s enslavement by the media, drugs and conformity.Bradbury’s powerful and poetic prose combines with uncanny insight into the potential of technology to create a novel which, decades on from first publication, still has the power to dazzle and shock.--back cover','Hardcover','Fahrenheit 451','https://images.gr-assets.com/books/1469704347l/17470674.jpg','227'),('90','Ernest Hemingway','It is the story of an old Cuban fisherman and his supreme ordeal: a relentless, agonizing battle with a giant marlin far out in the Gulf Stream. Using the simple, powerful language of a fable, Hemingway takes the timeless themes of courage in the face of defeat and personal triumph won from loss and transforms them into a magnificent twentieth-century classic.','Hardcover','The Old Man and the Sea','https://images.gr-assets.com/books/1329189714l/2165.jpg','132'),('92','Edgar Allan Poe','','Hardcover','The Complete Stories and Poems','https://images.gr-assets.com/books/1327942676l/23919.jpg','821');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id`,`username`,`password`,`email`,`dob`,`gender`,`address`,`mobile`,`status`) values (2,'ramu','ramu','ramu@gmail.com','1994-10-10','MALE','Ameerpet','9052016340','Accepted'),(3,'shiva','shiva','shiva@gmail.com','1993-10-10','MALE','Ameerpet','9876541230','Accepted'),(4,'chinna','chinna','chinna@gmail.com','2000-08-25','MALE','hyd','8639966858','Accepted'),(5,'chinnu','chinnu','chinnu@gmail.com','2023-07-02','MALE','hyd','8639966858','Accepted'),(6,'chintu','chintu','chintu@gmail.com','2023-07-17','MALE','hyd','8639966858','Accepted');

/*Table structure for table `userintention` */

DROP TABLE IF EXISTS `userintention`;

CREATE TABLE `userintention` (
  `username` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `productname` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `userintention` */

insert  into `userintention`(`username`,`category`,`productname`,`status`) values ('ramu','Mobiles','Samsung J7','Canceled'),('ramu','Mobiles','Mi','Canceled'),('shiva','Laptops','dell laptop','No'),('shiva','Laptops','dell laptop','Added'),('shiva','Laptops','dell laptop','Purchased'),('ramu','Mobiles','Samsung J7','No'),('ramu','Mobiles','Samsung J7','Added'),('ramu','Mobiles','Samsung J7','Purchased'),('ramu','Mobiles','Samsung J7','No'),('ramu','Mobiles','Samsung J7','No'),('ramu','Mobiles','Samsung J7','No'),('ramu','Mobiles','Samsung J7','No'),('chinnu','dell','dell new','Purchased'),('chinnu','dell','dell new','Canceled'),('shiva','dell','dell new','Purchased');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
